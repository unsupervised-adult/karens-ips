# ML Dashboard Feeder Module for SLIPS
# Integrates SLIPS detection data with Karen's IPS ML dashboard