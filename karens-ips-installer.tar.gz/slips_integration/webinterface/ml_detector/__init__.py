# SPDX-FileCopyrightText: 2025 Karen's IPS ML Ad Detector
# SPDX-License-Identifier: GPL-2.0-only

from .ml_detector_live import ml_detector

__all__ = ['ml_detector']